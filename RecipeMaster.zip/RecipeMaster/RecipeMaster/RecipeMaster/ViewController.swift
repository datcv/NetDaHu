//
//  ViewController.swift
//  RecipeMaster
//
//  Created by HECTOR TRAN on 16/5/18.
//  Copyright © 2018 RecipeMaster. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

